package MyProj;

import java.util.ArrayList;

public class Oven {
	private ArrayList<Food> foodList = new ArrayList<>();
	
	
	public void takeOffFoodFromOven() {
		if(foodList.isEmpty() == true) {
			System.out.println("Oven is Empty!");
		}
		else {
			int input;
			do {
				System.out.printf("Number Oven [1 - %d] : ", foodList.size());
				input = MainSystem.getMc().readInt();
				
			}while(input < 1 || input >= foodList.size());
			
			if(MainSystem.getCurrentSeconds() < foodList.get(input).getFoodTime()) {
				System.out.println("The Food is not cooked yet! =.=");
				System.out.println("Your live is decreased by 1");
				MainSystem.setLive(MainSystem.getLive()-1);
				foodList.remove(input);
			}else {
				System.out.printf("Good Job %s is finished!\n", foodList.get(input).getFoodName());
				System.out.printf("You Got %d\n", foodList.get(input).getFoodPrice());
				MainSystem.setMoney(MainSystem.getMoney()+foodList.get(input).getFoodPrice());
				foodList.remove(input);
			}
			
			
		}
	}
	
	public void updateFood() {
		if(foodList.isEmpty() == true) {
			System.out.println("Oven is Empty!");
		}else {
			int input;
			
			do {
				System.out.printf("Number Oven [1 - %d] : ", foodList.size());
				input = MainSystem.getMc().readInt();
				
			}while(input < 1 || input >= foodList.size());
			
			int additionalTime;
			
			do {
				System.out.print("Input additional time: ");
				additionalTime = MainSystem.getMc().readInt();
				
			}while(additionalTime <=0 );
			foodList.get(input).setFoodTime(foodList.get(input).getFoodTime()+additionalTime);
			foodList.get(input).setFoodBurntTime(foodList.get(input).getFoodBurntTime()+additionalTime);
			System.out.println("Successfully update food!");			
			
		}
		
	}
	
	
	
	
	public void insertFood() {
		String name;
		String desc;
		int price;
		int time;
		do {
			System.out.print("Food Name: ");
			name = MainSystem.getMc().read();
		}while(name.length() < 1);
		
		do {
			System.out.print("Food Desc: ");
			desc = MainSystem.getMc().read();
		}while(desc.length() < 1);
		
		do {
			System.out.print("Food Price: ");
			price = MainSystem.getMc().readInt();
		}while(price <= 0);
		
		do {
			System.out.print("Food Time: ");
			time = MainSystem.getMc().readInt();
		}while(time<= 0);
		
		Food food = new Food(name, desc, price, time);
		foodList.add(food);
	}
	

	public ArrayList<Food> getFoodList() {
		return foodList;
	}

	public void setFoodList(ArrayList<Food> foodList) {
		this.foodList = foodList;
	}
	
	
	
	
	
	
	
	
}
