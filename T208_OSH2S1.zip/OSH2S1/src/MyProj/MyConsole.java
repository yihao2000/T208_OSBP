package MyProj;

import nachos.machine.Machine;
import nachos.machine.SerialConsole;
import nachos.threads.Semaphore;

public class MyConsole {
	private static SerialConsole sc = Machine.console();
	private static Semaphore sema = new Semaphore(0);
	private static Character temp;
	
public MyConsole() {
		
		Runnable receive = new Runnable() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				temp = (char) sc.readByte();
				sema.V();
				
			}
		};
		Runnable send = new Runnable() {
			
			@Override
			public void run() {
				sema.V();
				
			}
		};
		sc.setInterruptHandlers(receive, send);
	}
	
	public void write(String s) {
		for(int i = 0 ; i < s.length() ; i++) {
			sc.writeByte(s.charAt(i));
			sema.P();
		}
			
}
	
	
	public void writeLn(String s) {
		write(s + "\n");
		
	}
	
	public String read() {
		String s= "";
		
		do {
			sema.P();
			if(temp == '\n') break;
				s+=temp;	
			
		}while(true);
		return s;
		
	}
	
	public Integer readInt() {
		String s = read();
		Integer x = 0;
		
		try {
			x = Integer.parseInt(s);
			
			
		}catch (Exception e){
			x -=1;
			
		}
		
		return x;
		
		
		
	}
	
	
	
}
