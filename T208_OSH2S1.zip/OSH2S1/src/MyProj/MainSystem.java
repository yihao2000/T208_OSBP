package MyProj;

import nachos.machine.Machine;
import nachos.machine.Timer;
import nachos.threads.Semaphore;

public class MainSystem {
	private static MyConsole mc = new MyConsole();
	private static int live = 3;
	private static int money = 0;
	private static long currentSeconds = 0;
	
	
	public MainSystem() {
		Timer timer = Machine.timer();
		Runnable handler = new Runnable() {

			@Override
			public void run() {
				currentSeconds = timer.getTime()/1000000;
					System.out.println("ovEn Manager");
					System.out.println("==============");
					System.out.println("Lives = "+live);
					System.out.println("Money = "+money);
					System.out.println("Seconds Elapsed = "+currentSeconds);
					
				
				
			}
		};
		
		timer.setInterruptHandler(handler);
		new Semaphore(0).P();
//		
		
		
	}


	public static MyConsole getMc() {
		return mc;
	}


	public static void setMc(MyConsole mc) {
		MainSystem.mc = mc;
	}


	public static int getLive() {
		return live;
	}


	public static void setLive(int live) {
		MainSystem.live = live;
	}


	public static int getMoney() {
		return money;
	}


	public static void setMoney(int money) {
		MainSystem.money = money;
	}


	public static long getCurrentSeconds() {
		return currentSeconds;
	}


	public static void setCurrentSeconds(long currentSeconds) {
		MainSystem.currentSeconds = currentSeconds;
	}
	
	
	
	
	
	
	
	

}
