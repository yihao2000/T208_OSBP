package MyProj;

public class Food {
	private String foodName;
	private String foodDesc;
	private int foodPrice;
	private int foodTime;
	private int foodBurntTime;
	
	
	
	public Food(String foodName, String foodDesc, int foodPrice, int foodTime) {
		this.foodName = foodName;
		this.foodDesc = foodDesc;
		this.foodPrice = foodPrice;
		this.foodTime = (int) (MainSystem.getCurrentSeconds() + foodTime);
		this.foodBurntTime = foodTime+10;
	}
	
	public String getFoodName() {
		return foodName;
	}
	public void setFoodName(String foodName) {
		this.foodName = foodName;
	}
	public String getFoodDesc() {
		return foodDesc;
	}
	public void setFoodDesc(String foodDesc) {
		this.foodDesc = foodDesc;
	}
	public int getFoodPrice() {
		return foodPrice;
	}
	public void setFoodPrice(int foodPrice) {
		this.foodPrice = foodPrice;
	}
	public int getFoodTime() {
		return foodTime;
	}
	public void setFoodTime(int foodTime) {
		this.foodTime = foodTime;
	}

	public int getFoodBurntTime() {
		return foodBurntTime;
	}

	public void setFoodBurntTime(int foodBurntTime) {
		this.foodBurntTime = foodBurntTime;
	}
	
	
	
	
	
	
	
	
}
