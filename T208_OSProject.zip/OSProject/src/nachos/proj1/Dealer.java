package nachos.proj1;

import java.util.ArrayList;

public class Dealer {
	private  ArrayList<Card> cardList = new ArrayList<>();

	public  ArrayList<Card> getCardList() {
		return cardList;
	}

	public void setCardList(ArrayList<Card> cardList) {
//		Dealer.cardList = cardList;
	}
	
	
	
	
	

}
