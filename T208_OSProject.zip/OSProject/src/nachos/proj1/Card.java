package nachos.proj1;

public class Card {
	int value;
	String cardName;
	
	
	public Card(int value) {
		this.value = (value % 14);
		cardName = cardNameConverter(value);
	}
	
	
	public String cardNameConverter(int value) {
		if(value <= 9) {		
			return this.value + " of Heart";
		}else if(value == 10) {
			
			return "Jack of Heart";
		}else if(value == 11) {
			
			return "Queen of Heart";
			
		}else if(value == 12) {
			return "King of Heart";
		}else if(value == 13) {
			return "As of Heart";
			
			
		}else if(value <= 22) {
			return this.value + " of Spade";
		}else if(value == 23) {
			return "Jack of Spade";
		}else if(value ==24) {
			return "Queen of Spade";
		}else if(value == 25) {
			return "King of Spade";
		}else if(value == 26) {
			return "As of Spade";
			
			
			
			
		}else if(value <= 35) {
			return this.value + " of Diamond";
		}else if(value == 36) {
			return "Jack of Diamond";
		}else if(value == 37) {
			return "Queen of Diamond";
		}else if(value == 38) {
			return "King of Diamond";
		}else if(value == 39) {
			return "As of Diamond";
			
			
			
		}else if(value <= 48) {
			return this.value +" of Club";
		}else if(value == 49) {
			return "Jack of Club";
		}else if(value == 50) {
			return "Queen of Diamond";
		}else if(value == 51) {
			return "King of Diamond";
		}else if(value == 52) {
			return "As of Diamond";
		}
		
	
		return "Invalid Name";
		
	}


	public int getValue() {
		return value;
	}


	public void setValue(int value) {
		this.value = value;
	}


	public String getCardName() {
		return cardName;
	}


	public void setCardName(String cardName) {
		this.cardName = cardName;
	}
	
	

}
