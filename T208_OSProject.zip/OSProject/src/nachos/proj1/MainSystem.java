package nachos.proj1;

import java.util.ArrayList;
import java.util.Random;

import nachos.machine.Machine;
import nachos.machine.MalformedPacketException;
import nachos.machine.NetworkLink;
import nachos.machine.Packet;

public class MainSystem {
	
	//GameController
	int playerAmount = 0;
	int currPlayer = 0;
	Boolean isTurn = false;
	Boolean enterGame = false;
	Boolean updatingDatabase = false;
	Boolean isGameStillPlaying = true;
	
	//Player
	Player player;
	ArrayList<Player> playerList = new ArrayList<>();
	Boolean newAccount = true;
	
	NetworkLink nl;
	ArrayList<Messages> messages; 
	 File file = new File("highscore.txt");
	private static Console console;
	
	public MainSystem() {
		messages = new ArrayList<>();
		console = new Console();
		nl = Machine.networkLink();
		
		
		Runnable send = new Runnable() {
		
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				
			}
		};
		
		Runnable receive = new Runnable() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				
				Packet pkt = nl.receive();
				int src = pkt.srcLink;
				int dest = nl.getLinkAddress();
			
				String content = new String(pkt.contents);
				System.out.println("Content: "+content);
				
				if(content.equals("Joined") && currPlayer < playerAmount && nl.getLinkAddress() == 0) {
					currPlayer++;
					if(currPlayer == playerAmount) {
						enterGame = true;
					}
				}else if(content.equals("Play") ) {
					enterGame = true;
				}else if(content.charAt(0) == 'U'  && content.charAt(1) == '#') {
					String parts [] = content.split("#");
					playerList.add(new Player(parts[0]));
				}else if(content.contains("@")){
					String parts[] = content.split("@");
					int firstValue = Integer.parseInt(parts[0]);
					int secondValue = Integer.parseInt(parts[1]);
					int index = Integer.parseInt(parts[2]);
					
					playerList.get(index).getCardList().add(new Card(firstValue));
					playerList.get(index).getCardList().add(new Card(secondValue));
					
				}
				
//				
//				if(nl.getLinkAddress() == 0 && enterGame == false) {
//					System.out.println("Masuk ke pertambahan player");
//					
//					if(content.equals("Joined") && currPlayer < playerAmount) {
//						currPlayer++;
//					}
//				}else if(nl.getLinkAddress() > 0 && enterGame == false){
//					System.out.println("Masuk ke play");
//					if(content.equals("Play")) {
//						enterGame = true;
//					}
//					
//				}
//				 if(nl.getLinkAddress() == 0 && currPlayer == playerAmount && enterGame == false) {
//					System.out.println("Auto update");
//					enterGame = true;
//					setStartGame();
//				}
//				 if(content.equals("hai#Update")){
//					System.out.println("hai");
//					System.out.println("AAAA");
//					String parts [] = content.split("#");
//					player = new Player(parts[0]);
//					playerList.add(player);		
//					
//				}
				
			
				
				
				
				
				
			}
		};
		nl.setInterruptHandlers(receive, send);
		
		
		newAccount = true;
		int mainMenuInput = 0;
		
		do {
			file.readScoreboard();
			console.writeln("WU Blackjack");
			console.writeln("Welcome dealer!");
			console.writeln("1. Start game");
			console.writeln("2. See high scores");
			console.writeln("3. Exit");
			mainMenuInput = console.readInt();	
			
			
			if(mainMenuInput == 1) {
				
				if(nl.getLinkAddress() == 0) {
					
					do {
						console.writeln("Insert total player [1-3]: ");
						playerAmount = console.readInt();
					}while(playerAmount < 1 || playerAmount > 3);
					
					while(enterGame == false) {
						console.writeln("Waiting...");
//						cls();	
					}
					
					setStartGame();
			
					
//						try {
//							String content = "PLAY";
//							Packet pkt1 = new Packet(1, nl.getLinkAddress(), content.getBytes());
//							Packet pkt2 = new Packet(2, nl.getLinkAddress(), content.getBytes());
//							Packet pkt3 = new Packet(3, nl.getLinkAddress(), content.getBytes());
//							nl.send(pkt1);
//							nl.send(pkt2);
//							nl.send(pkt3);
//						} catch (MalformedPacketException e) {
//							e.printStackTrace();
//						}
//						System.out.println("Sent");
					
					
					//Distributing card to each player
						for(int i = 0 ; i < playerList.size() ; i++) {
							Random rand = new Random();
							Card card1 = new Card(rand.nextInt(52)+1);
							Card card2 = new Card(rand.nextInt(52)+1);
							playerList.get(i).getCardList().add(card1);
							System.out.println("Dealing "+ card1.getCardName() + " to player " + i+1);
							playerList.get(i).getCardList().add(card2);
							System.out.println("Dealing "+ card2.getCardName() + " to player "+i+1);
							
							String content = card1.getValue() + "@" + card2.getValue() + "@" + i;
							Packet pkt;
							try {
								pkt = new Packet(i, nl.getLinkAddress(), content.getBytes());
								nl.send(pkt);
							} catch (MalformedPacketException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							
							
						}
						
						
						
						
					
					
					
					
				}else if(nl.getLinkAddress() > 0) {
					if(newAccount == true) {
						String username;
						int point = 500;
						
						do {			
							for(int i = 0 ; i < playerList.size() ; i++) {
								playerList.get(i).getUsername();
							}
							console.write("Write username [2-10 chars]: ");
							username = console.read();						
						}while(username.length() < 2 || username.length() > 10);
						player = new Player(username);
						playerList.add(player);
						newAccount = false;		
						
						
						updateDatabaseSignal(username);
						}
					
					int playerIndex = nl.getLinkAddress()-1;
					
	
					if(playerList.get(playerIndex).getPoint() < 50) {
						console.write("Not enough points!");
						pause();
					}else if(playerList.get(playerIndex).getPoint() >= 50) {
						console.writeln("WU Blackjack");
						console.writeln("Welcome "+playerList.get(playerIndex).getUsername());
						console.writeln("Current Score: "+playerList.get(playerIndex).getPoint());
						console.writeln("1. Join a session");
						console.writeln("2. See high scores");
						console.writeln("3. Exit");
						int gameMenuInput = 0;
						do {
							console.write("Choose >> ");
							gameMenuInput = console.readInt();
						
						}while(gameMenuInput < 1 || gameMenuInput > 3);
						
						if(gameMenuInput == 1) {
							
							try {
								String content = "Joined";
								Packet pkt = new Packet(0, nl.getLinkAddress(), content.getBytes());
								nl.send(pkt);
							} catch (MalformedPacketException e) {
								e.printStackTrace();
							}
							
							while(enterGame != true) {
								console.writeln("Joining...");
							}
							
							while(isGameStillPlaying == true) {
								
							}
							
							
									
						}else if(gameMenuInput == 2) {
							
							String text = file.readFile();
							if(text!=null) {
								file.printScoreboard();
								pause();
								
							}else {
								console.writeln("Scoreboard File not found!");
								console.writeln("Scoreboard");
								console.writeln("----------------------------");
								console.writeln("----------------------------");
								pause();
							}
							
						}
						
						
						
					}
					
					
					
				}	
			}else if(mainMenuInput == 2) {
				String text = file.readFile();
				if(text!=null) {
					file.printScoreboard();
					pause();
					
				}else {
					console.writeln("Scoreboard File not found!");
					console.writeln("Scoreboard");
					console.writeln("----------------------------");
					console.writeln("----------------------------");
					pause();
				}
				
				
			}
			
		}while(mainMenuInput !=3);
		
		
		
		
	}



	public static Console getConsole() {
		return console;
	}

	public static void setConsole(Console console) {
		MainSystem.console = console;
	}
	
	
	public void pause() {
		console.writeln("Press enter to continue...");
		console.read();
		
	}
	
	public void cls() {
		for(int i = 0 ; i < 25 ; i++) {
			console.writeln("");
		}
		
	}
	
	public void updateDatabaseSignal(String username) {
		String update = "U#"+username;
		for(int i = 0 ; i < 4 ; i++) {
			if(i != nl.getLinkAddress()) {
				try {
				
				Packet pkt = new Packet(i, nl.getLinkAddress(), update.getBytes());
				nl.send(pkt);
			} catch (MalformedPacketException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
				
			}
		}
		
		
	}
	
	public void setStartGame() {
		String content = "Play";
		
		for(int i = 1 ; i <= playerAmount ; i++) {
			try {
				Packet pkt = new Packet(i, nl.getLinkAddress(), content.getBytes());
				nl.send(pkt);
			} catch (MalformedPacketException e) {
				e.printStackTrace();
			}
			
		}
		
		
		
	}
	
	
	
	
}
