package nachos.proj1;

import java.util.ArrayList;

public class Player {
	private  ArrayList<Card> cardList = new ArrayList<>();
	private String username;
	private int point;
	
	
	
	public Player(String username) {
		this.username = username;
		this.point = 500;	
		
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public int getPoint() {
		return point;
	}
	public void setPoint(int point) {
		this.point = point;
	}
	public ArrayList<Card> getCardList() {
		return cardList;
	}
	public void setCardList(ArrayList<Card> cardList) {
		this.cardList = cardList;
	}
	
	
	
	
	
	
	
	
	
	
	

}
