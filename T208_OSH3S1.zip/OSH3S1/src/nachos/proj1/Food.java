package nachos.proj1;

public class Food implements Runnable{
	private String name;
	private int price;
	private int duration;
	private boolean isReady;
	
	
	
	
	
	public Food(String name, int price, int duration, boolean isReady) {
		this.name = name;
		this.price = price;
		this.duration = duration;
		this.isReady = isReady;
	}
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getDuration() {
		return duration;
	}
	public void setDuration(int duration) {
		this.duration = duration;
	}
	public boolean isReady() {
		return isReady;
	}
	public void setReady(boolean isReady) {
		this.isReady = isReady;
	}
	
	public String printReady() {
		if(this.isReady == true) {
			return "Ready Stock";
		}
		return "Out of Stock";
		
	}
	
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		int number = Main.getFoodList().indexOf(this);
		number+=1;
        System.out.println("Menu "+number);
         System.out.println("Menu's Name: "+this.name);
        System.out.println("Menu's Price: "+this.price);
        System.out.println("Menu's Status: "+ this.printReady());
        System.out.println("Menu's Cook Duration: "+this.duration+" second(s)");
        System.out.println("====================================================\n");
		
		
		
	}
	
	
	
	
	
	
	

}
