package nachos.proj1;

public class Order implements Runnable{
	private Food food;
	private int quantity;
	
	public Order(Food food, int quantity) {
		this.food = food;
		this.quantity = quantity;
	}

	
	
	
	public Food getFood() {
		return food;
	}




	public void setFood(Food food) {
		this.food = food;
	}




	public int getQuantity() {
		return quantity;
	}




	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}




	@Override
	public void run() {
//		// TODO Auto-generated method stub
		
		System.out.println("Cooking " + this.quantity + " " + this.food.getName());
		System.out.println("Needs: "+this.food.getDuration()+" seconds(s)");
		int amount = this.quantity;
		int duration = this.food.getDuration();
		
		
		
		for(int i = 0 ; i < quantity ; i++ ) {
			System.out.println("Cooking " +(i+1) + " " + this.food.getName());
			for(int j = duration ; j > 0 ; j--) {
				System.out.println(j + " seconds(s) more");
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			System.out.println("Order " + this.food.getName() + " completed!");
		}
		
		Main.setCoin(Main.getCoin()+this.food.getPrice()*this.quantity);
		
		
		
		
	}
	
	
	
	

}
