package nachos.proj1;

import java.util.Vector;

import nachos.threads.KThread;
import nachos.threads.ThreadQueue;

public class MyThreadQueue extends ThreadQueue{
	
	Vector<KThread> queue = new Vector<KThread>();
	
	public MyThreadQueue() {
	}

	
	//Notify Thread Queue ketika ada thread yang akan masuk kedalam antrian
	@Override
	public void waitForAccess(KThread thread) {
		// TODO Auto-generated method stub
		queue.add(thread);
		
	}

	//Notify thread queue ketika thread berikutnya siao dijalankan
	@Override
	public KThread nextThread() {
		// TODO Auto-generated method stub
		
		if(queue.isEmpty()) return null;
		
//		FIFO (First in First out)
		return queue.remove(0);
		
		// LIFO (Last in first out)
//		return queue.remove(queue.size()-1);
		
		
	}

	@Override
	public void acquire(KThread thread) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void print() {
		// TODO Auto-generated method stub
		
	}

}
