package nachos.proj1;

import java.util.ArrayList;
import java.util.Vector;

import nachos.threads.KThread;

public class Main {
	private static Console con = new Console();
	private static Vector<Order> orders = new Vector<>();
	private static Vector <Food> foodList = new Vector<>();
	private static AutoOrder autoOrder;
	private static Food food;
	private static int coin;
	
	public Main() {
		
		coin = 0;
		int menu = -1;
		autoOrder = new AutoOrder();
		do {
			
			con.writeln("BreakVost Dash");
			con.writeln("============================");
			con.writeln("1. Start Game");
			con.writeln("0. Exit");
			menu = con.readInt();
			
			if(menu == 1) {
				int gameMenu = -1;
				do {
					con.writeln("Your Coin: "+coin);
					con.writeln("List of menu");
					for(int i = 0 ; i < foodList.size() ; i++) {
						con.writeln((i+1) + " " + foodList.get(i).getName() + " (" +foodList.get(i).printReady() +")");
					}
					con.writeln("");
					con.writeln("1. Add Menu");
					con.writeln("2. Update Menu");
					con.writeln("3. Remove Menu");
					con.writeln("4. Take Order");
					con.writeln("5. Process Order");
					con.writeln("0. Exit");
					con.write(">> ");
					gameMenu = con.readInt();
					
					if(gameMenu == 1) {
						String foodName;
						int foodPrice;
						int foodDuration;
						
						do {
							con.write("Insert menu's name [3-20 characters]: ");
							foodName = con.read();
							
						}while(foodName.length() < 3 || foodName.length() > 20);
						
						do {
							
							con.write("Insert menu's price [$5 - $20]: ");
							foodPrice= con.readInt();
						}while(foodPrice < 5 || foodPrice > 20);
						
						do {
							con.write("Insert menu's cook duration [ 1 - 4 second(s)]: ");						
							foodDuration = con.readInt();
						}while(foodDuration < 1 || foodDuration > 4);
						
						food = new Food(foodName, foodPrice, foodDuration, true);
						foodList.add(food);	
						
					}else if(gameMenu == 2) {
						if(foodList.isEmpty() == true) {
							con.writeln("There is no menu to be updated!");
							pause();
							
						}else {
							printEachMenu();	
							
							int updateMenuInput;
							do {			
								con.writeln("1. Update Menu Status");
								con.writeln("0. Exit");
								con.write(">> ");
								updateMenuInput = con.readInt();
							}while(updateMenuInput < 0 || updateMenuInput > 1);
							if(updateMenuInput == 1) {
								int selection;
								
								do {
									con.write("Menu's index you want to change status [1 - "+foodList.size()+"]: ");
									selection = con.readInt();
									selection-=1;
								}while(selection < 0 || selection >= foodList.size());
								if(foodList.get(selection).isReady() == true) {
									foodList.get(selection).setReady(false);
								}else if(foodList.get(selection).isReady() == false) {
									foodList.get(selection).setReady(true);
								}
							}
							
							
							
						}			
					}else if(gameMenu == 3) {
						
					}else if(gameMenu == 4) {
						if(orders.size() >= 10) {
							con.writeln("Order has reached maximum limit of 10 !");
							pause();
						}else {
							printEachMenu();
							
							boolean isAnyFoodAvailable = false;
							int selection;
							
							do {
								con.writeln("1. Take Order");
								con.writeln("0. Exit");
								con.write(">> ");
								selection = con.readInt();
							}while(selection < 0 || selection > 1);
							
							if(selection == 1) {
								for (Food food : foodList) {
									if(food.isReady() == true) {
										isAnyFoodAvailable = true;
									}else {
										isAnyFoodAvailable = false;
									}
								}
								if(isAnyFoodAvailable == false) {
									con.writeln("Sorry, there is no ready stock menu...");
									pause();
								}else if(isAnyFoodAvailable == true) {
									int foodChoice;
									do {
										con.writeln("Menu's index to order [1 - "+ (foodList.size()) +"]: ");
										foodChoice = con.readInt();
										foodChoice-=1;
									}while(foodChoice < 0 || foodChoice >= foodList.size());
									
									int foodQuantity;
									do {
										con.writeln("Menu's quantity to order [1 - 5]: ");
										foodQuantity = con.readInt();	
									}while(foodQuantity < 1 || foodQuantity > 5 );
									
												
									if(foodList.get(foodChoice).isReady() == false) {
										con.writeln("Menu is out of stock!");
										pause();
									}else if(foodList.get(foodChoice).isReady() == true) {
										orders.add(new Order(foodList.get(foodChoice), foodQuantity));
										con.writeln("Success take an order!");
										pause();
									}							
								}		
							}	
						}
						
					}else if(gameMenu == 5) {
						if(orders.isEmpty() == true) {
							con.writeln("There is no order to be proceed yet!");
							pause();
						}else if(orders.isEmpty() == false) {
							serveOrder();			
							
						}
						
					}
					
					
				}while(gameMenu != 0);
				
				
				
				
				
				
				
			}
//			else if(menu == 2) {
////				serveOrder();
////			}
			
			
		}while(menu != 0);
	}
	
	
//	private void createOrder() {
//		String name;
//		int price;
//		
//		do {
//			con.write("Insert order Name [5-10]: ");
//			name = con.read();
//			
//			
//		}while(name.length()< 5 || name.length() > 10);
//		
//		do {
//			con.write("Insert Order price [> 15000]: ");
//			price = con.readInt();
//			
//		}while(price > 15000);
//		
//		orders.add(new Order(name, price));
//		
//	}
	
	
	public void printEachMenu() {
	
		for(Food f : foodList) {
			new KThread(f).fork();
		}	
		
	}
	
	
	
	public void pause() {
		con.writeln("Press enter to continue...");
		con.read();
		
	}
	
	
	private void serveOrder() {
		//Scheduler
			//Runnable Target
			new KThread(orders.remove(0)).fork();;
		
		
	}
	



	public Console getCon() {
		return con;
	}


	public void setCon(Console con) {
		this.con = con;
	}


	

	public static Vector<Order> getOrders() {
		return orders;
	}


	public static void setOrders(Vector<Order> orders) {
		Main.orders = orders;
	}


	public AutoOrder getAutoOrder() {
		return autoOrder;
	}


	public void setAutoOrder(AutoOrder autoOrder) {
		this.autoOrder = autoOrder;
	}


	public Food getFood() {
		return food;
	}


	public void setFood(Food food) {
		this.food = food;
	}


	public static Vector<Food> getFoodList() {
		return foodList;
	}


	public static void setFoodList(Vector<Food> foodList) {
		Main.foodList = foodList;
	}


	public static int getCoin() {
		return coin;
	}


	public static void setCoin(int coin) {
		Main.coin = coin;
	}
	
	
	
	
	
	
	
	
	
}
