package nachos.proj1;

import java.util.Random;

public class AutoOrder implements Runnable{
	

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
		while(true) {
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			Random rand = new Random();
			int foodSelection = rand.nextInt(Main.getFoodList().size()-1);
			int orderQuantity = rand.nextInt(5)+1;
			Main.getOrders().add(new Order(Main.getFoodList().get(foodSelection), orderQuantity));
			System.out.println("A");
		}
	}
	
	

}
