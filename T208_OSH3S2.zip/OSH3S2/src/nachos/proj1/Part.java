package nachos.proj1;

public class Part {
	private static int position;
	private static String name;
	

}
