package nachos.proj1;

public class Main {
	Board board = new Board();
	Console console = new Console();
	
	public Main() {
		loadAction();
		loadProperty();
		loadTourism();
		
		
		
		int mainMenuInput = -1;
		do {
			
			
			console.writeln("mOSopoly");
			console.writeln("==========");
			console.writeln("1. Play Game");
			console.writeln("2. High Score");
			console.writeln("3. Exit");
			console.write(">> ");
			mainMenuInput = console.readInt();
			
		}while(mainMenuInput != 3);
		
		
		
	}
	public void loadAction() {
		
		
		
	}
	
	public void loadProperty() {
		
		
	}
	public void loadTourism() {
		
		
	}

}
