package nachos.proj1;

public class Property extends Part{
	int rentPrice;
	int propertyValue;
	int upgradePrice;
	int buildingAmount;
	
	
}
