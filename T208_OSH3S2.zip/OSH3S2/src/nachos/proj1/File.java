package nachos.proj1;

import java.util.ArrayList;

import nachos.machine.FileSystem;
import nachos.machine.Machine;
import nachos.machine.OpenFile;

public class File {
    
    private String fileName;

    public File(String fileName) {
        super();
        this.fileName = fileName;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }
    
    public String readFile() {
        FileSystem fs = Machine.stubFileSystem();
        OpenFile of = fs.open(fileName, false);
        
        if(of == null) {
            return null;
        }
        byte[] buffer = new byte[999];
        of.read(buffer, 0, of.length());
        return new String(buffer);    
        
    }
    
    public void readProperty() {
        FileSystem fs = Machine.stubFileSystem();
        OpenFile of = fs.open(fileName, false);
        int max = 0;
        
        byte[] buffer = new byte[9999];
        of.read(buffer, 0, of.length());
        String all = new String(buffer);
        for(int i = 0 ; i < all.length() ; i++) {
            if(all.charAt(i) == '\r') {
                max++;
            }
        }
        String [] entries = all.split("\r");
        int counter = 0;
        
        while(counter < max) {
        	String [] parts = entries[counter].split("#");
        	
            entry = new Entry();
                entry.setName(parts[0]);
                try {
                	entry.setScore(Integer.parseInt(parts[1]));
                }catch(NumberFormatException e) {
                	break;
                }
            entryList.add(entry);
            System.out.println("Entry + 1");
            counter++;
        }
        sort();
        
    }
    
    public void readWords() {
        FileSystem fs = Machine.stubFileSystem();
        OpenFile of = fs.open(fileName, false);
        int max = 0;
        
        byte[] buffer = new byte[9999];
        of.read(buffer, 0, of.length());
        String all = new String(buffer);
        for(int i = 0 ; i < all.length() ; i++) {
            if(all.charAt(i) == '\r') {
                max++;
            }
        }
        String [] entries = all.split("\r");
        int counter = 0;
        
        while(counter < max) {
        	String [] parts = entries[counter].split("#");
            entry = new Entry();
                entry.setName(parts[0]);
                try {
                	entry.setScore(Integer.parseInt(parts[1]));
                }catch(NumberFormatException e) {
                	break;
                }
            entryList.add(entry);
            System.out.println("Entry + 1");
            counter++;
        }
        sort();
        
    }
    
    public void printScoreboard() {
        
        Main.getConsole().writeln("Scoreboard");
        Main.getConsole().writeln("---------------------");
        for(int i = 0; i < entryList.size() ;i++) {
            Main.getConsole().writeln("["+(i+1)+ "] " + entryList.get(i).getName() + " : " + entryList.get(i).getScore());        
        }
        Main.getConsole().writeln("---------------------");
    }
    
    
    public void sort() {
         int n = entryList.size();
            Entry temp;  
             for(int i=0; i < n; i++){  
                for(int j=1; j < (n-i); j++){  
                    if(entryList.get(j-1).getScore() < entryList.get(j).getScore()){  
                         temp = entryList.get(j-1);
                         entryList.set(j-1, entryList.get(j));
                         entryList.set(j, temp);
                                 
          }  
                              
       }  
    }  
 }
    
    public void writeFile(String content) {
        FileSystem fs = Machine.stubFileSystem();
        OpenFile of = fs.open(fileName,true);
        //true -> buat baru dan kalo udah ada sebelumnya maka isinya akan dihapus
        of.write(content.getBytes(), 0, content.length());
        
        
    }
    
    public void appendFile(String content) {
        FileSystem fs = Machine.stubFileSystem();
        OpenFile of = fs.open(fileName, false);
        if(of == null)of = fs.open(fileName, false);
        of.write(of.length(), content.getBytes(), 0, content.length());
    }
    
    
    
    
    
}