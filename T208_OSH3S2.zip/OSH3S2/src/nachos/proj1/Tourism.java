package nachos.proj1;

public class Tourism extends Part{
	int price;

}
