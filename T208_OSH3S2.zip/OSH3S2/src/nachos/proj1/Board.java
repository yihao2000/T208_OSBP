package nachos.proj1;

import java.util.ArrayList;

public class Board {
	public static ArrayList<Part> boardPart = new ArrayList<>();

	public static ArrayList<Part> getBoardPart() {
		return boardPart;
	}

	public static void setBoardPart(ArrayList<Part> boardPart) {
		Board.boardPart = boardPart;
	}
	
	
	
	

}
