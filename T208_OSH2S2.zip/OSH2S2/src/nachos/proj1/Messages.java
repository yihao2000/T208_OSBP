package nachos.proj1;

public class Messages {
	private String title, content;
	private int sender, dest;
	
	
	
	
	public Messages(int sender, int dest, String title, String content) {
		super();
		this.sender = sender;
		this.dest = dest;
		this.title = title;
		this.content = content;
		
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public int getSender() {
		return sender;
	}
	public void setSender(int sender) {
		this.sender = sender;
	}
	public int getDest() {
		return dest;
	}
	public void setDest(int dest) {
		this.dest = dest;
	}
	
	
	

}
