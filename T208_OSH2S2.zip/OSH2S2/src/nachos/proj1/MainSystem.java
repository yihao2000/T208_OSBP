package nachos.proj1;

import java.util.ArrayList;
import java.util.Random;

import nachos.machine.Machine;
import nachos.machine.MalformedPacketException;
import nachos.machine.NetworkLink;
import nachos.machine.Packet;

public class MainSystem {
	
	File file = new File("scoreboard.txt");
	private static Console console;
	ArrayList<Messages> messages;
	NetworkLink nl;
	Player p;
	
	int lives;
	int score;
	int id;
	boolean gameStarted;
	boolean turn;
	boolean isEnter;
	boolean inPlay;
	boolean isBack;
	
	
	
	
	public MainSystem() {
			
		messages = new ArrayList<>();
		console = new Console();
		nl = Machine.networkLink();
		
		lives = 3;
		score = 30;
		gameStarted = false;
		turn = false;
		isEnter = false;
		inPlay = false;
		isBack = false;
		
		
		
		Runnable send = new Runnable() {
		
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				System.out.println("Message is sent!");
				
			}
		};
		
		Runnable receive = new Runnable() {
			
			@Override
			public void run() {
				Packet pkt = nl.receive();
				int src = pkt.srcLink;
				int dest = nl.getLinkAddress();
				String content = new String(pkt.contents);
				System.out.println("Content: "+content);
				
				if(content.equals("Enter")) {
					isEnter = true;
				}else if(content.equals("Start")) {
					gameStarted = true;
				}else if(content.equals("Back")) {
					isBack = true;
				}else if(content.equals("Next")) {
					turn = true;
				}else {
					String[] atrs = content.split("#");
					p = new Player(atrs[0], atrs[1], atrs[2]);
				}
				
				
			}
		};
		nl.setInterruptHandlers(receive, send);
		
		
		int choice = 0;
		
		do {
			
			
			file.readScoreboard();
			console.write("Hang Man [Player "+ (nl.getLinkAddress()+1) +"]\n");
			console.writeln("1. Play");
			console.writeln("2. View Scoreboard");
			console.writeln("3. Exit");
			console.write(">> ");
			choice = console.readInt();
				
			if(choice == 1) {
				inPlay = true;
				while(inPlay == true) {
					if(nl.getLinkAddress() == 3) {
						sendEnterSignal();
					}
					while(gameStarted == false && isEnter == false && isBack ==false){
						console.writeln("Please wait for other players..");
					}
					if(isBack == true) {
						console.writeln("Game start has been cancelled.");
						inPlay = false;
						pause();
						continue;
					}
					if(isEnter == true) {
						console.writeln("Player is enough. Start the game ?  [y/n] (Case Sensitive)");
						String confirm = "";
						while(!confirm.equals("y") && !confirm.equals("n")) {
							confirm = console.read();
						}
						if(confirm.equals("y")) {
							sendEnterSignal();
							isEnter = false;
							gameStarted = true;
							isBack = false;
						}else{
							isEnter = false;
							gameStarted = false;
							sendBackSignal();
							isBack = true;
						}
					}
					if(gameStarted == true) {
						if(nl.getLinkAddress() == 0) {
							turn = true;
						}
						if(p != null) {			
						if(turn  == false){
							console.writeln("");
							console.writeln(p.getGuess());
							console.writeln("Hint: "+p.getHint());
							console.writeln("======================");
							console.writeln("Not your turn! Waiting..");
						}else {
							console.writeln(p.getGuess());
							console.writeln("Hint: "+p.getHint());
							console.writeln("======================");
							char letterguess = '0';
								while(letterguess < 'A' || letterguess > 'Z') {
									console.write("Input a guess letter [Uppercase format] :");
									letterguess = console.read().charAt(0);
								}
								turn = false;
								console.writeln("GUESSED : "+letterguess);
								if(p.attempt(letterguess)) {
									console.writeln("CORRECT GUESS!");
									
								}else {
									console.writeln("WRONG GUESS! -1 live(s)");
									
								}
						}
						
						}
						int dest = -1;
						String word = "", hint = "", guess = "";
						ArrayList<Player> words = new ArrayList<>();
						words.add(new Player("PER","C",generateWord("PER","")));
						words.add(new Player("SUT","C",generateWord("SUT","")));
						words.add(new Player("PIS","C",generateWord("PIS","")));
						words.add(new Player("POS","C",generateWord("POS","")));	
						Random r = new Random();
						int sel = r.nextInt(4);
						Player seld = words.get(sel);
						word = seld.getCorrect();
						hint = seld.getHint();
						guess = seld.getGuess();
						p = seld;
						
						int dest1 = -1,dest2 = -1,dest3 = -1;
						
						if(turn == true) {
							if(nl.getLinkAddress() == 0) {
								dest1 = 1;
								dest2 = 2;
								dest3 = 3;
							}else if (nl.getLinkAddress() == 1){
								dest1 = 2;
								dest2 = 3;
								dest3 = 0;
							}else if (nl.getLinkAddress() == 2) {
								dest1 = 3;
								dest2 = 0;
								dest3 = 1;
							}else if (nl.getLinkAddress() == 3) {
								dest1 = 0;
								dest2 = 1;
								dest3 = 2;
							}
							turn = false;
							
							String content = word+"#"+hint+"#"+guess;
							String nextTurn = "NEXT";
							
							try {
								Packet pkt1 = new Packet(dest1, nl.getLinkAddress(), content.getBytes());
								Packet pkt2 = new Packet(dest2, nl.getLinkAddress(), content.getBytes());
								Packet pkt3 = new Packet(dest3, nl.getLinkAddress(), content.getBytes());
								Packet pktnext = new Packet(dest1, nl.getLinkAddress(), nextTurn.getBytes());
								nl.send(pkt1);
								nl.send(pkt2);
								nl.send(pkt3);
								nl.send(pktnext);
							} catch (MalformedPacketException e) {
								e.printStackTrace();
							}
						}
					}
				}
				
				
				
				
				
				
			}else if(choice == 2) {
				String text = file.readFile();
				if(text!=null) {
					file.printScoreboard();
					pause();
					
				}else {
					console.writeln("Scoreboard File not found!");
					console.writeln("Scoreboard");
					console.writeln("----------------------------");
					console.writeln("----------------------------");
					pause();
					
				}
				
			}
				
			
			
			
		}while(choice !=3);
		
		
	}
	
	
	
	public void checkTurn(Player p) {
		String letterguess = "";

			while(letterguess.length() <= 0) {
				System.out.print("Input a guess character :");
				letterguess = console.read();
			}
			System.out.println("Guessed : "+letterguess);
			
			
	}
	
	public void sendStartSignal() {
		if(nl.getLinkAddress() == 0) {
			String content = "Start";
			for(int i = 1 ; i <= 3; i++) {
				
				try {
					Packet pkt = new Packet(i, nl.getLinkAddress(), content.getBytes());
					nl.send(pkt);
					
				} catch (MalformedPacketException e) {
					e.printStackTrace();
				}
			}
			
		}
	}
	
	
	public void sendEnterSignal() {
		if(nl.getLinkAddress() == 3) {
			String content = "Enter";
				
			try {
				Packet pkt1 = new Packet(0, nl.getLinkAddress(), content.getBytes());
				nl.send(pkt1);
			} catch (MalformedPacketException e) {
				e.printStackTrace();
			}
		}
		
	}
	
	public void sendBackSignal() {
		if(nl.getLinkAddress() == 0) {
			String content = "Back";
			
			for(int i = 1 ; i <= 3 ; i++) {
				
				try {
					Packet pkt = new Packet(i, nl.getLinkAddress(), content.getBytes());
					nl.send(pkt);				
				} catch (MalformedPacketException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	public String generateWord(String wordToGuess, String guess) {
		int wtgLength = wordToGuess.length();
		int gLength = guess.length();
		String generated = "";
		for(int i = 0; i < wtgLength; i++) {
			boolean isFilled = false;
			for(int j = 0; j < gLength; j++) {
				if(guess.charAt(j) == wordToGuess.charAt(i)) {
					generated+=guess.charAt(j);
					isFilled = true;
				}
			}
			if (!isFilled) {
				generated+="_";
			}
			generated+=" ";
		}
		
		return generated;
	}
	
	
	
	
	public void pause() {
		console.writeln("Press enter to continue...");
		console.read();
		
	}


	public static Console getConsole() {
		return console;
	}


	public static void setConsole(Console console) {
		MainSystem.console = console;
	}
	
	
	
	
	

}
